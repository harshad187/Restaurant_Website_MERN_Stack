import "./App.css";
import { BrowserRouter as Router, Routes ,Route } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import Home from "./Pages/Home";
import NotFound from "./Pages/NotFound";
import Success from "./Pages/Success";
//import HomePage from "./components/HomePage";
import MenuPage from "./components/MenuPage";
//import Navbar from "./components/Navbar";

const App = () => {
  return (
  <Router>
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="*" element={<NotFound />} />
      <Route path="/Success" element={<Success />} />
      <Route path="/menu" element={<MenuPage />} />
    </Routes>
    <Toaster />
  </Router>
  );
  /*function HomePage() {
    return (
      <div className="home-container">
        <h1>Welcome to Adsul Restaurant</h1>
        <button className="menuBtn">
          <Link to="/menu">OUR MENU</Link>
        </button>
      </div>
    );
  }
  
  function App() {
    return (
      <Router>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/menu" element={<MenuPage />} />
        </Routes>
      </Router>
    );
  }*/
   /* function App() {
      return (
        <Router>
          <Navbar />
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/menu" element={<MenuPage />} />
          </Routes>
        </Router>
      );
    }  
      */
  
};

export default App
