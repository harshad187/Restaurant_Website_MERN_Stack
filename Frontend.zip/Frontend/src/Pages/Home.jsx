import React from 'react'
import HeroSection from "../components/HeroSection.jsx"
import About from '../components/About.jsx'
import Qualities from "../components/Qualities.jsx"
import Menu from "../components/Menu.jsx"
import WhoAreWe from '../components/WhoAreWe.jsx'
import Team from '../components/Team.jsx'
import Reservation from '../components/Reservation.jsx'
import Footer from '../components/Footer.jsx'
import Success from './Success.jsx'
//import MenuPage from '../components/MenuPage.jsx'
//import HomePage from '../components/HomePage.jsx'




const Home = () => {
  return (
    <>
    <HeroSection />
    <About />
    <Qualities />
    <Menu />
    <WhoAreWe/>
    <Team/>
    <Reservation/>
    <Footer/>
    <Success/>
  
    
  
  
    </>
  )
}

export default Home