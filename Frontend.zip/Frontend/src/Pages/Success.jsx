import React, { useEffect, useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { HiOutlineArrowNarrowRight } from "react-icons/hi";

const Success = () => {
  const [countdown, setCountdown] = useState(10);
  const navigate = useNavigate();
  const location = useLocation();

  // Check if the page is accessed after a reservation
  const isReservationSuccess = location.state?.reservationSuccess;

  useEffect(() => {
    if (!isReservationSuccess) {
      // If no reservation was made, redirect immediately
      navigate("/");
      return;
    }

    const timeoutId = setInterval(() => {
      setCountdown((preCount) => {
        if (preCount === 1) {
          clearInterval(timeoutId);
          navigate("/");
        }
        return preCount - 1;
      });
    }, 1000);

    return () => clearInterval(timeoutId);
  }, [navigate, isReservationSuccess]);

  if (!isReservationSuccess) return null; // Don't render if there's no reservation

  return (
    <>
    <section className="notFound">
      <div className="container">
        <img src="/sandwich.png" alt="success" />
        <h1><b>RESERVATION IS DONE SUCCESSFULLY</b></h1>
        <h1>Redirecting to Home in {countdown} seconds...</h1>
        <Link to={"/"}>
          Back to Home <HiOutlineArrowNarrowRight />
        </Link>
      </div>
    </section>
    </>
  );
};

export default Success;
