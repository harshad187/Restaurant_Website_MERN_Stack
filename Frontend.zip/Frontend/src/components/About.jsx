import React from "react";
import { Link } from "react-router-dom";
import { HiOutlineArrowNarrowRight } from "react-icons/hi";

const About = () => {
  return (
    <>
      <section className="about" id="about">
        <div className="container">
          <div className="banner">
            <div className="top">
              <h1 className="heading">ABOUT US</h1>
              <p>The only thing we're serious about is food.</p>
            </div>
            <p className="mid">
            "At <b>ADSUL RESTAURANT</b>, we bring you a global culinary experience with a menu that celebrates flavors from around the world. From the rich and comforting taste of Italian pasta to the refined elegance of Continental cuisine, the bold spices of Arabic delicacies, and the authentic, soulful essence of Maharashtrian food—we have something to satisfy every craving. Our commitment to hygiene and quality is at the heart of everything we do, ensuring that every dish is not only delicious but also prepared with the utmost care. Whether you're indulging in international flavors or savoring the taste of home, we promise an unforgettable dining experience where taste meets tradition in the cleanest and most welcoming ambiance. Please Free to call us on <b>"7249586166"</b> or just mail on <b>"harshadadsul@1029"</b>."
            </p>
            
           
            
          </div>
          <div className="banner">
            <img src="/about.png" alt="about" />
          </div>
        </div>
      </section>
    </>
  );
};

export default About;
