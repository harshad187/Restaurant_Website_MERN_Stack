import React from "react";
import "./MenuPage.css";

const MenuPage = () => {
  return (
    <div className="menu-container">
      <h1 className="menu-title">OUR MENU</h1>
      <p className="menu-subtitle">
        Discover a variety of authentic and delicious dishes, crafted with fresh
        ingredients and traditional flavors.
      </p>

      <div className="menu-section">
        <h2>Starters</h2>
        <ul>
          <li>Panner Pizza Special  - ₹250</li>
          <li>Chicken Tandoori - ₹250</li>
          <li>Papdi Chaat - ₹90</li>
          <li>Veg Manchurian - ₹159</li>
          <li>Famous Mutton Burger - ₹200</li>
        </ul>
      </div>
      <div className="menu-section">
        <h2>Continental Cuisine</h2>
        <ul>
          <li>Grilled Fish - ₹550</li>
          <li>Roasted Lamb Rumb - ₹450</li>
          <li>Citrus Cured salmon  - ₹250</li>
          <li>Ratatouille - ₹270</li>
          <li>Gazpacho - ₹220</li>
          <li>Italian Spaghetti - ₹230</li>
          <li>Italian Pasta - ₹250</li>
          <li>Paella - ₹220</li>
          <li>Bratwurst - ₹220</li>
        </ul>
      </div>
      <div className="menu-section">
        <h2>Arabic Cuisine</h2>
        <ul>
          <li>Mussels Soup - ₹350</li>
          <li>Pan Seared Sea Bass  - ₹280</li>
          <li>Falafel - ₹250</li>
          <li>Fattoush- ₹150</li>
          <li>Baklava - ₹120</li>
          <li>Mansaf - ₹340</li>
          <li>Arabic Kofta - ₹260</li>
        </ul>
      </div>

      <div className="menu-section">
        <h2>Indian Cuisine</h2>
        <ul>
          <li>Butter Chicken - ₹180</li>
          <li>Paneer Butter Masala - ₹210</li>
          <li>Dal Makhani - ₹120</li>
          <li>Chicken Biryani - ₹180</li>
          <li>Vegetable Biryani - ₹170</li>
          <li>Rogan Josh (Mutton Curry) - ₹120</li>
        </ul>
      </div>

      <div className="menu-section">
        <h2>Indian Breads</h2>
        <ul>
          <li>Butter Naan - ₹40</li>
          <li>Garlic Naan - ₹45</li>
          <li>Plain Paratha - ₹30</li>
          <li>Aloo Paratha - ₹70</li>
        </ul>
      </div>

      <div className="menu-section">
        <h2>Desserts</h2>
        <ul>
          <li>Gulab Jamun (2 pcs) - ₹60</li>
          <li>Rasmalai - ₹80</li>
          <li>Kulfi (Mango/Pista) - ₹90</li>
          <li>Stuffed Strawberry Cake - 150₹</li>
        </ul>
      </div>

      <div className="menu-section">
        <h2>Beverages</h2>
        <ul>
          <li>Masala Chai - ₹30</li>
          <li>Sweet Lassi - ₹50</li>
          <li>Buttermilk - ₹45</li>
          <li>Mango Shake - ₹80</li>
        </ul>
      </div>
    </div>
  );
};

export default MenuPage;
