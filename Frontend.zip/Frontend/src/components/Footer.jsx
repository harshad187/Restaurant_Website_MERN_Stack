import React from "react";

const Footer = () => {
  return (
    <footer>
      <div className="container">
        <div className="banner">
          <div className="left">ADSUL RESTAURANT</div>
          <div className="right">
            <p>Near Pawar Chowk ,Front of Shivaji Stadium ,Sangli ,Maharashtra ,India</p>
            <p>Open: 09:00 AM - 11:00 PM</p>
          </div>
        </div>
        <div className="banner">
          <div className="left">
            <p>Developed By <b>Harshad Adsul,Aarya Raut and Kishor Sutar.</b>.</p>
          </div>
          <div className="right">
            <p>All Rights Reserved By ADSUL RESTAURANT.</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;