import React from "react";
import { data } from "../restApi.json";

const Team = () => {
  return (
    <section className="team" id="team">
      <div className="container">
        <div className="heading_section">
          <h1 className="heading">OUR TEAM</h1>
          <p>
          At ADSUL RESTAURANT , our culinary team is the heart and soul of everything we do. Handpicked from prestigious 3-star hotels, our chefs bring years of expertise, passion, and creativity to every dish. Their dedication to excellence ensures that each plate is a masterpiece, blending rich flavors with artistic presentation.

Beyond the kitchen, our entire team—from our skilled sous chefs to our attentive service staff—shares a commitment to providing an unforgettable dining experience. With a deep understanding of fine dining and a love for hospitality, they work seamlessly to make every visit special.

Join us and savor the expertise of a team that turns every meal into a celebration!
          </p>
        </div>
        <div className="team_container">
          {data[0].team.map((element) => {
            return (
              <div className="card" key={element.id}>
                <img src={element.image} alt={element.name} />
                <h3>{element.name}</h3>
                <p>{element.designation}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Team;
