 import app from "./app.js";

 app.listen(process.env.PORT, () =>{
     console.log(`Server Running On Port ${process.env.PORT}`);

 });
// const PORT = process.env.PORT || 4000;

// app.listen(PORT, () => {
//   console.log(`Server running on port ${PORT}`);
// }).on("error", (err) => {
//   if (err.code === "EADDRINUSE") {
//     console.log(`Port ${PORT} is in use, trying another port...`);
//     app.listen(0, () => {
//       console.log(`Server started on a different port.`);
//     });
//   } else {
//     console.error(err);
//   }
// });

// import express from "express";
// import dotenv from "dotenv";

// // Load environment variables
// dotenv.config();

// // Create an Express app
// const app = express();

// // Set the port (use dynamic available port if needed)
// const PORT = process.env.PORT || 4000;

// app.listen(PORT, () => {
//   console.log(`Server running on port ${PORT}`);
// }).on("error", (err) => {
//   if (err.code === "EADDRINUSE") {
//     console.log(`Port ${PORT} is in use, trying another port...`);
//     app.listen(0, () => {
//       console.log(`Server started on a different port.`);
//     });
//   } else {
//     console.error(err);
//   }
// });

